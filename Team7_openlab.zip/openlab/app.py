# Store this code in 'app.py' file

from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
import requests
from bs4 import BeautifulSoup


def getdata(url):
    r = requests.get(url)
    return r.text

a=[]
htmldata = getdata("https://www.geeksforgeeks.org/binary-search-tree-data-structure/")
soup = BeautifulSoup(htmldata, 'html.parser')
for item in soup.find_all('img'):
	if 'BST' in item['src']: 
		a.append(item['src'])




app = Flask(__name__)


app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'password'
app.config['MYSQL_DB'] = 'geeklogin'

mysql = MySQL(app)
@app.route('/home')
def home():
	return render_template('page.html', msg = 'Logged in successfully !')
@app.route('/lms')#from eval to lms
def expeval():
	return render_template('exp.html', msg = 'Logged in successfully !')
@app.route('/info')
def info():
     # print(a[0])
	return render_template('info.html', msg =a[0])

@app.route('/')
@app.route('/login', methods =['GET', 'POST'])
def login():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
		username = request.form['username']
		password = request.form['password']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM accounts WHERE username = % s AND password = % s', (username, password, ))
		account = cursor.fetchone()
		if account:
			session['loggedin'] = True
			session['id'] = account['id']
			session['username'] = account['username']
			msg = 'Logged in successfully !'
			return redirect(url_for('home'))

		else:
			msg = 'Incorrect username / password !'
	return render_template('login.html', msg = msg)

@app.route('/logout')
def logout():
	session.pop('loggedin', None)
	session.pop('id', None)
	session.pop('username', None)
	return redirect(url_for('login'))

@app.route('/register', methods =['GET', 'POST'])
def register():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
		account = cursor.fetchone()
		if account:
			msg = 'Account already exists !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = 'Invalid email address !'
		elif not re.match(r'[A-Za-z0-9]+', username):
			msg = 'Username must contain only characters and numbers !'
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			cursor.execute('INSERT INTO accounts VALUES (NULL, % s, % s, % s)', (username, password, email, ))
			mysql.connection.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('register.html', msg = msg)

@app.route('/exp', methods =['GET', 'POST'])
def insertbooks():
	if request.method == 'POST':
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		name = request.form['bookname']
		author= request.form['author']
		genre = request.form['genre']
		publishdate = request.form['publishdate']
		location = request.form['location']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('INSERT INTO books VALUES (NULL, % s, % s,% s,% s,% s)', (name, author, genre, publishdate, location, ))
		mysql.connection.commit()
		return render_template('exp.html')

@app.route('/bookinfo', methods =['GET', 'POST'])
def bookinfo():
	return render_template('bookinfo.html',data="")

@app.route('/booksearch', methods =['GET','POST'])
def booksearch():	
	if 	request.method == 'POST':
		search = request.form['booksearch']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM books WHERE name = % s', (search, ))
		data = cursor.fetchone()
		print(data)
		cursor.close()
		return render_template('bookinfo.html', data=data)
		
	
if __name__ == '__main__':
	app.run(debug=True)
